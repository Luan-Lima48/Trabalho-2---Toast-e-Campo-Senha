package com.rafael.firstapplication

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.rafael.firstapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        enableEdgeToEdge()
        setContentView(view)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //val button = findViewById<Button>(R.id.button)
        //val editText = findViewById<EditText>(R.id.editText)
        val editText = binding.editText           // campo de e-mail
        val editTextSenha = binding.editTextSenha // campo de senha
        val button = binding.button

        button.setOnClickListener {
            // Obtém o texto digitado em cada campo
            val email = editText.text.toString()
            val senha = editTextSenha.text.toString()

            // Exibe e-mail e senha em um Toast (sem validações, conforme o enunciado)
            Toast.makeText(
                this,
                "Email: $email\nSenha: $senha",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}